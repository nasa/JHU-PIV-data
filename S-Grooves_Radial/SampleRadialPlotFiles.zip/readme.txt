
S grooves radial plots:

Load plot code: sample_velocity_plot_Radial_nasa.m into Matlab
Load big data file *.mat
Load S_groove_point.mat, radial S grooves variables (3 variables)